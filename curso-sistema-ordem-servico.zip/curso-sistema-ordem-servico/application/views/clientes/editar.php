<?php $this->load->view('layout/sidebar'); ?>

<!-- Main Content -->
<div id="content">
    <?php $this->load->view('layout/navbar'); ?>

    <!-- Begin Page Content -->
    <div class="container-fluid">

        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?= base_url(); ?>">Home</a></li>
                <li class="breadcrumb-item"><a href="<?= base_url($this->router->fetch_class()); ?>"><?= $this->router->fetch_class(); ?></a></li>
                <li class="breadcrumb-item cliente_ativo" aria-current="page"><?= $titulo; ?></li>
            </ol>
        </nav>

        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <div class="row">
                    <?php if (isset($cliente)) { ?>
                        <div class="col-6">
                            <h6 class="m-0 font-weight-bold text-primary"><?= $titulo; ?></h6>
                            <p><i class="ik ik-edit">&nbsp;</i>Em processo de atualização de dados...</p>
                        </div>
                        <div class="col-6">
                            <a href="<?= base_url('clientes/novo/'); ?>" class="btn btn-outline-primary float-right"><i class="fa fa-user-plus"></i> &nbsp;&nbsp;Cadastrar clientes</a>
                            <p><?php echo (isset($cliente) ? '<i class="ik ik-calendar"></i>&nbsp;Última alteração: ' . formata_data_banco_com_hora($cliente->cliente_data_alteracao) : ''); ?></p>
                        </div>
                    <?php } else { ?>
                        <div class="col-6">
                            <h6 class="m-0 font-weight-bold text-primary"><?= $titulo; ?></h6>
                        </div>
                        <div class="col-6">
                            <a href="<?= base_url('clientes/novo/'); ?>" class="btn btn-outline-primary float-right"><i class="fa fa-user-plus"></i> &nbsp;&nbsp;Cadastrar clientes</a>
                        </div>
                    <?php } ?>
                </div>
            </div>

            <?php if ($message = $this->session->flashdata('error')): ?>
                <div class="row mt-3 mb-1">
                    <div class="col-lg-12">
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <h5><i class="fas fa-exclamation-triangle">&nbsp;</i><?= $message; ?></h5>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><i class="ik ik-x"></i></button>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <div class="card-body">
                <form method="POST" name="form_edit">
                    <fieldset class="border p-3">
                        <legend class="border font-small">&nbsp;&nbsp; Dados do Cliente</legend>

                        <div class="row">
                            <div class="col-6 form-group">
                                <label for="nome">Nome:</label>
                                <input type="text" class="form-control" placeholder="Seu nome" 
                                       id="cliente_nome" name="cliente_nome" value="<?= $cliente->cliente_nome; ?>">
                                       <?= form_error('cliente_nome', '<small class="form-text text-danger">', '</small>'); ?>
                            </div>

                            <div class="col-6 form-group">
                                <label for="sobrenome">Sobrenome: </label>
                                <input type="text" class="form-control" placeholder="Seu sobrenome" 
                                       id="cliente_sobrenome" name="cliente_sobrenome" value="<?= $cliente->cliente_sobrenome; ?>">
                                       <?= form_error('cliente_sobrenome', '<small class="form-text text-danger">', '</small>'); ?>
                            </div>

                            <div class="col-6 form-group">
                                <label for="cliente_data_nascimento">Data nascimento: </label>
                                <input type="text" class="form-control" 
                                       id="cliente_data_nascimento" name="cliente_data_nascimento" value="<?= formataDataView($cliente->cliente_data_nascimento); ?>">
                                       <?= form_error('cliente_data_nascimento', '<small class="form-text text-danger">', '</small>'); ?>
                            </div>

                            <div class="col-6 form-group">
                                <?php if ($cliente->cliente_tipo == 1): ?>
                                    <label>CPF:</label>
                                    <input type="text" class="form-control cpf" placeholder="<?= ($cliente->cliente_tipo == 1 ? 'CPF do cliente' : 'CNPJ do cliente'); ?>" 
                                           id="cliente_cpf" name="cliente_cpf" value="<?= $cliente->cliente_cpf_cnpj; ?>" maxlength="18">
                                           <?= form_error('cliente_cpf', '<small class="form-text text-danger">', '</small>'); ?>
                                <?php else: ?>
                                    <label>CNPJ:</label>
                                    <input type="text" class="form-control cnpj" placeholder="<?= ($cliente->cliente_tipo == 1 ? 'CPF do cliente' : 'CNPJ do cliente'); ?>" 
                                           id="cliente_cnpj" name="cliente_cnpj" value="<?= $cliente->cliente_cpf_cnpj; ?>" maxlength="18">
                                           <?= form_error('cliente_cnpj', '<small class="form-text text-danger">', '</small>'); ?>
                                <?php endif; ?>
                            </div>

                            <div class="col-6 form-group">
                                <?php if ($cliente->cliente_tipo == 1): ?>
                                    <label>RG:</label>
                                <?php else: ?>
                                    <label>Inscrição Estadual:</label>
                                <?php endif; ?>
                                <input type="text" class="form-control" placeholder="<?= ($cliente->cliente_tipo == 1 ? 'RG do cliente' : 'I.E do cliente'); ?>" 
                                       id="cliente_rg_ie" name="cliente_rg_ie" value="<?= $cliente->cliente_rg_ie; ?>">
                                       <?= form_error('cliente_rg_ie', '<small class="form-text text-danger">', '</small>'); ?>
                            </div>

                            <div class="col-6 form-group">
                                <label for="cliente_email">E-mail:</label>
                                <input type="text" class="form-control" placeholder="E-mail" 
                                       id="cliente_email" name="cliente_email" value="<?= $cliente->cliente_email; ?>">
                                       <?= form_error('cliente_email', '<small class="form-text text-danger">', '</small>'); ?>
                            </div>

                            <div class="col-6 form-group">
                                <label for="cliente_telefone">Telefone:</label>
                                <input type="text" class="form-control sp_celphones" placeholder="Telefone" 
                                       id="cliente_telefone" name="cliente_telefone" value="<?= $cliente->cliente_telefone; ?>">
                                       <?= form_error('cliente_telefone', '<small class="form-text text-danger">', '</small>'); ?>
                            </div>

                            <div class="col-6 form-group">
                                <label for="cliente_celular">Celular:</label>
                                <input type="text" class="form-control sp_celphones" placeholder="Celular" 
                                       id="cliente_celular" name="cliente_celular" value="<?= $cliente->cliente_celular; ?>">
                                       <?= form_error('cliente_celular', '<small class="form-text text-danger">', '</small>'); ?>
                            </div>

                            <div class="col-6 form-group">
                                <label for="cliente_cep">CEP:</label>
                                <input type="text" class="form-control cep" placeholder="CEP" 
                                       id="cliente_cep" name="cliente_cep" value="<?= $cliente->cliente_cep; ?>">
                                       <?= form_error('cliente_cep', '<small class="form-text text-danger">', '</small>'); ?>
                            </div>

                            <div class="col-6 form-group">
                                <label for="cliente_endereco">Endereço:</label>
                                <input type="text" class="form-control" placeholder="Endereço" 
                                       id="cliente_endereco" name="cliente_endereco" value="<?= $cliente->cliente_endereco; ?>">
                                       <?= form_error('cliente_endereco', '<small class="form-text text-danger">', '</small>'); ?>
                            </div>

                            <div class="col-6 form-group">
                                <label for="cliente_numero_endereco">Numero:</label>
                                <input type="text" class="form-control" placeholder="Numero" 
                                       id="cliente_numero_endereco" name="cliente_numero_endereco" value="<?= $cliente->cliente_numero_endereco; ?>">
                                       <?= form_error('cliente_numero_endereco', '<small class="form-text text-danger">', '</small>'); ?>
                            </div>

                            <div class="col-6 form-group">
                                <label for="cliente_bairro">Bairro:</label>
                                <input type="text" class="form-control" placeholder="Bairro" 
                                       id="cliente_bairro" name="cliente_bairro" value="<?= $cliente->cliente_bairro; ?>">
                                       <?= form_error('cliente_bairro', '<small class="form-text text-danger">', '</small>'); ?>
                            </div>

                            <div class="col-6 form-group">
                                <label for="cliente_complemento">Complemento:</label>
                                <input type="text" class="form-control" placeholder="Complemento" 
                                       id="cliente_complemento" name="cliente_complemento" value="<?= $cliente->cliente_complemento; ?>">
                                       <?= form_error('cliente_complemento', '<small class="form-text text-danger">', '</small>'); ?>
                            </div>

                            <div class="col-6 form-group">
                                <label for="cliente_cidade">Cidade:</label>
                                <input type="text" class="form-control" placeholder="Cidade" 
                                       id="cliente_cidade" name="cliente_cidade" value="<?= $cliente->cliente_cidade; ?>">
                                       <?= form_error('cliente_cidade', '<small class="form-text text-danger">', '</small>'); ?>
                            </div>

                            <div class="col-6 form-group">
                                <label for="cliente_estado">Estado:</label>
                                <input type="text" class="form-control uf" placeholder="Estado" 
                                       id="cliente_estado" name="cliente_estado" value="<?= $cliente->cliente_estado; ?>">
                                       <?= form_error('cliente_estado', '<small class="form-text text-danger">', '</small>'); ?>
                            </div>

                            <div class="col-6 form-group">
                                <label for="cliente_nome_pai">Pai:</label>
                                <input type="text" class="form-control" placeholder="Pai" 
                                       id="cliente_nome_pai" name="cliente_nome_pai" value="<?= $cliente->cliente_nome_pai; ?>">
                                       <?= form_error('cliente_nome_pai', '<small class="form-text text-danger">', '</small>'); ?>
                            </div>

                            <div class="col-6 form-group">
                                <label for="cliente_nome_mae">Mãe:</label>
                                <input type="text" class="form-control" placeholder="Mãe" 
                                       id="cliente_nome_mae" name="cliente_nome_mae" value="<?= $cliente->cliente_nome_mae; ?>">
                                       <?= form_error('cliente_nome_mae', '<small class="form-text text-danger">', '</small>'); ?>
                            </div>

                            <div class="col-6 form-group">
                                <label for="cliente_tipo">Tipo:</label>
                                <select name="cliente_tipo" class="form-control">
                                    <option value="1" <?= ($cliente->cliente_tipo == 1 ? 'selected' : ''); ?> >Pessoa física</option>
                                    <option value="2" <?= ($cliente->cliente_tipo == 2 ? 'selected' : ''); ?> >Pessoa jurpidica</option>
                                </select>
                            </div>

                            <div class="col-6 form-group">
                                <label for="cliente_ativo">Ativo:</label>
                                <select class="custom-select" name="cliente_ativo" id="cliente_ativo">
                                    <option value="0" <?= ($cliente->cliente_ativo == 0 ? 'selected' : ''); ?> >Não</option>
                                    <option value="1" <?= ($cliente->cliente_ativo == 1 ? 'selected' : ''); ?> >Sim</option>
                                </select>
                            </div>

                            <div class="col-12 form-group">
                                <label for="cliente_obs">Observações:</label>
                                <textarea type="text" class="form-control" placeholder="Observações" id="cliente_obs" name="cliente_obs"><?= $cliente->cliente_obs; ?></textarea>
                                <?= form_error('cliente_obs', '<small class="form-text text-danger">', '</small>'); ?>
                            </div>

                            <div class="col-12 text-center mt-5">
                                <input type="hidden" name="cliente_tipo" id="cliente_tipo" value="<?= $cliente->cliente_tipo; ?>" >
                                <input type="hidden" name="cliente_id" id="cliente_id" value="<?= $cliente->cliente_id; ?>" >
                                <button type="submit" class="btn btn-primary btn-lg">Salvar</button>
                                <a href="<?= base_url($this->router->fetch_class()); ?>" class="btn btn-secondary btn-lg">Cancelar</a>
                            </div>
                        </div>
                    </fieldset>
                </form>
            </div>
        </div>
    </div>
    <!-- /.container-fluid -->
</div>
<!-- End of Main Content -->