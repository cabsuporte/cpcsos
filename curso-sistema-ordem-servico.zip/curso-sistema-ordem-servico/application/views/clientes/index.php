<?php $this->load->view('layout/sidebar'); ?>

<!-- Main Content -->
<div id="content">
    <?php $this->load->view('layout/navbar'); ?>

    <!-- Begin Page Content -->
    <div class="container-fluid">

        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?= base_url(); ?>">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page"><?= $titulo; ?></li>
            </ol>
        </nav>

        <!-- Bloco mensagem Flashdata - Sucesso -->
        <?php if ($message = $this->session->flashdata('sucesso')): ?>
            <div class="row">
                <div class="col-md-12">
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <i class="fas fa-check-circle"></i>
                        <strong><?= $message; ?></strong>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        <!--// Bloco mensagem Flashdata - Sucesso -->
        <!-- Bloco mensagem Flashdata - Error -->
        <?php if ($message = $this->session->flashdata('error')): ?>
            <div class="row">
                <div class="col-md-12">
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <i class="fas fa-check-circle"></i>
                        <strong><?= $message; ?></strong>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        <!--// Bloco mensagem Flashdata - Error -->

        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <div class="row">
                    <div class="col-6">
                        <h6 class="m-0 font-weight-bold text-primary"><?= $titulo; ?></h6>
                    </div>
                    <div class="col-6">
                        <a href="<?= base_url('clientes/novo/'); ?>" class="btn btn-outline-primary float-right"><i class="fa fa-user-tie"></i> &nbsp;&nbsp;Cadastrar Clientes</a>
                    </div>
                </div>
            </div>

            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered dataTable" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr class="text-center">
                                <th>#</th>
                                <th>Cliente</th>
                                <th>CPF / CNPJ</th>
                                <th>E-mail</th>
                                <th>Tipo cliente</th>
                                <th>Ativo</th>
                                <th class="no-sort">Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($clientes as $cliente) { ?>
                                <tr class="text-center">
                                    <td><?= $cliente->cliente_id; ?></td>
                                    <td><?= $cliente->cliente_nome; ?></td>
                                    <td><?= $cliente->cliente_cpf_cnpj; ?></td>
                                    <td><?= $cliente->cliente_email; ?></td>
                                    <td><?= ($cliente->cliente_tipo == 1 ? 'Pessoa física' : 'Pessoa jurpidica'); ?></td>
                                    <td><?= ($cliente->cliente_ativo == 1 ? '<span class="badge badge-pill badge-success mb-1"><i class="fas fa-lock-open">&nbsp;</i>Sim</span>' : '<span class="badge badge-pill badge-danger mb-1"><i class="fas fa-lock">&nbsp;</i>Não</span>'); ?></td>
                                    <td>
                                        <a href="<?= base_url('clientes/editar/' . $cliente->cliente_id); ?>" class="btn btn-sm btn-primary"><i class="fa fa-user-edit"></i></a>
                                        <a href="javascript(void)" class="btn btn-sm btn-danger text-white" 
                                           title="Excluir <?= $this->router->fetch_class(); ?>" 
                                           data-toggle="modal" 
                                           data-target="#user-<?= $cliente->cliente_id; ?>"><i class="fa fa-user-times"></i></a>
                                    </td>
                                </tr>

                                <!-- Modal Excluir Dados -->
                            <div class="modal fade" id="user-<?= $cliente->cliente_id; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterLabel" aria-hidden="true">
                                <div class="modal-dialog modal-dialog-centered" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title text-danger" id="exampleModalCenterLabel">
                                                <i class="fas fa-exclamation-triangle text-danger"></i>&nbsp; 
                                                Tem certeza da exclusão do usuário abaixo?
                                            </h5>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                        </div>
                                        <div class="modal-body">
                                            <p class="text-uppercase">Usuário: <b><?= $cliente->cliente_nome; ?></b></p>
                                            <p>Se deseja realmente excluir o registro, clique em <strong class="text-uppercase">Sim, excluir!</strong></p>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" 
                                                    data-toggle="tooltip" 
                                                    data-placement="bottom"
                                                    title="Cancelar exclusão"
                                                    class="btn btn-secondary" 
                                                    data-dismiss="modal">Não, voltar</button>
                                            <a href="<?= base_url($this->router->fetch_class() . '/Del/' . $cliente->cliente_id); ?>" 
                                               class="btn btn-danger"
                                               data-toggle="tooltip" 
                                               data-placement="bottom" 
                                               title="Excluir <?= $this->router->fetch_class(); ?>">Sim, excluir!</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!--// Modal Excluir Dados -->
                        <?php } ?>
                        </tbody>
                        <tfoot>
                            <tr class="text-center">
                                <th>#</th>
                                <th>Cliente</th>
                                <th>CPF / CNPJ</th>
                                <th>E-mail</th>
                                <th>Tipo cliente</th>
                                <th>Ativo</th>
                                <th>Ações</th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <!-- /.container-fluid -->
</div>
<!-- End of Main Content -->