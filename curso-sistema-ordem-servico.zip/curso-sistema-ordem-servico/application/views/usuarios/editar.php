<?php $this->load->view('layout/sidebar'); ?>

<!-- Main Content -->
<div id="content">
    <?php $this->load->view('layout/navbar'); ?>

    <!-- Begin Page Content -->
    <div class="container-fluid">

        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?= base_url(); ?>">Home</a></li>
                <li class="breadcrumb-item"><a href="<?= base_url($this->router->fetch_class()); ?>"><?= $this->router->fetch_class(); ?></a></li>
                <li class="breadcrumb-item active" aria-current="page"><?= $titulo; ?></li>
            </ol>
        </nav>

        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <div class="row">
                    <div class="col-6">
                        <h6 class="m-0 font-weight-bold text-primary"><?= $titulo; ?></h6>
                    </div>
                    <div class="col-6">
                        <a href="<?= base_url('usuarios/novo/'); ?>" class="btn btn-outline-primary float-right"><i class="fa fa-user-plus"></i> &nbsp;&nbsp;Cadastrar usuários</a>
                    </div>
                </div>
            </div>

            <?php if ($message = $this->session->flashdata('error')): ?>
                <div class="row mt-3 mb-1">
                    <div class="col-lg-12">
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <h5><i class="fas fa-exclamation-triangle">&nbsp;</i><?= $message; ?></h5>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><i class="ik ik-x"></i></button>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <div class="card-body">
                <form method="POST" name="form_edit">
                    <div class="row">
                        <div class="col-6 form-group">
                            <label for="nome">Nome:</label>
                            <input type="text" class="form-control" placeholder="Seu nome" 
                                   id="first_name" name="first_name" value="<?= $usuario->first_name; ?>">
                            <?= form_error('first_name', '<small class="form-text text-danger">', '</small>'); ?>
                        </div>
                        <div class="col-6 form-group">
                            <label for="sobrenome">Sobrenome:</label>
                            <input type="text" class="form-control" placeholder="Seu sobrenome" 
                                   id="last_name" name="last_name" value="<?= $usuario->last_name; ?>">
                            <?= form_error('last_name', '<small class="form-text text-danger">', '</small>'); ?>
                        </div>
                        <div class="col-6 form-group">
                            <label for="username">Usuário:</label>
                            <input type="text" class="form-control" placeholder="Usuário" 
                                   id="username" name="username" value="<?= $usuario->username; ?>">
                            <?= form_error('username', '<small class="form-text text-danger">', '</small>'); ?>
                        </div>
                        <div class="col-6 form-group">
                            <label for="email">E-mail:</label>
                            <input type="email" class="form-control" placeholder="Seu e-mail" 
                                   id="email" name="email" value="<?= $usuario->email; ?>">
                            <?= form_error('email', '<small class="form-text text-danger">', '</small>'); ?>
                        </div>
                        <div class="col-6 form-group">
                            <label for="perfil_usuario">Perfil:</label>
                            <select name="perfil_usuario" class="form-control">
                                <option value="1" <?= ($perfil_usuario->id == 1 ? 'selected' : ''); ?> >Administrador</option>
                                <option value="2" <?= ($perfil_usuario->id == 2 ? 'selected' : ''); ?> >Vendedor</option>
                            </select>
                        </div>
                        <div class="col-6 form-group">
                            <label for="active">Ativo:</label>
                            <select class="form-control" name="active" id="active">
                                <option value="0" <?= ($usuario->active == 0 ? 'selected' : ''); ?> >Não</option>
                                <option value="1" <?= ($usuario->active == 1 ? 'selected' : ''); ?> >Sim</option>
                            </select>
                        </div>
                        <div class="col-6 form-group">
                            <label for="senha">Senha:</label>
                            <input type="password" class="form-control" placeholder="Digite uma senha" id="password" name="password">
                            <?= form_error('password', '<small class="form-text text-danger">', '</small>'); ?>
                        </div>
                        <div class="col-6 form-group">
                            <label for="confirme_senha">Confirme a senha:</label>
                            <input type="password" class="form-control" placeholder="Confirme a senha" id="password_confirm" name="password_confirm">
                            <?= form_error('password_confirm', '<small class="form-text text-danger">', '</small>'); ?>
                        </div>
                        <div class="col-12 text-center">
                            <input type="hidden" name="usuario_id" id="usuario_id" value="<?= $usuario->id; ?>" >
                            <button type="submit" class="btn btn-primary btn-lg">Salvar</button>
                            <a href="<?= base_url('usuarios/'); ?>" class="btn btn-secondary btn-lg">Cancelar</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- /.container-fluid -->
</div>
<!-- End of Main Content -->