<?php $this->load->view('layout/sidebar'); ?>

<!-- Main Content -->
<div id="content">
    <?php $this->load->view('layout/navbar'); ?>

    <!-- Begin Page Content -->
    <div class="container-fluid">

        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?= base_url(); ?>">Home</a></li>
                <li class="breadcrumb-item"><a href="<?= base_url($this->router->fetch_class()); ?>"><?= $this->router->fetch_class(); ?></a></li>
                <li class="breadcrumb-item active" aria-current="page"><?= $titulo; ?></li>
            </ol>
        </nav>

        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <div class="row">
                    <div class="col-6">
                        <h6 class="m-0 font-weight-bold text-primary"><?= $titulo; ?></h6>
                    </div>
                    <div class="col-6">
                        <a href="<?= base_url('usuarios/novo/'); ?>" class="btn btn-outline-primary float-right"><i class="fa fa-user-plus"></i> &nbsp;&nbsp;Cadastrar usuários</a>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <form action="" method="POST" name="form_novo">
                    <div class="row">
                        <div class="col-6 form-group">
                            <label for="nome">Nome:</label>
                            <input type="text" class="form-control" placeholder="Seu nome"
                                   id="first_name" name="first_name" value="<?= set_value('first_name'); ?>">
                            <?= form_error('first_name', '<small class="form-text text-danger">', '</small>'); ?>
                        </div>
                        <div class="col-6 form-group">
                            <label for="sobrenome">Sobrenome:</label>
                            <input type="text" class="form-control" placeholder="Seu sobrenome"
                                   id="last_name" name="last_name" value="<?= set_value('last_name'); ?>">
                            <?= form_error('last_name', '<small class="form-text text-danger">', '</small>'); ?>
                        </div>
                        <div class="col-6 form-group">
                            <label for="username">Usuário:</label>
                            <input type="text" class="form-control" placeholder="Usuário"
                                   id="username" name="username" value="<?= set_value('username'); ?>">
                            <?= form_error('username', '<small class="form-text text-danger">', '</small>'); ?>
                        </div>
                        <div class="col-6 form-group">
                            <label for="email">E-mail:</label>
                            <input type="email" class="form-control" placeholder="Seu e-mail"
                                   id="email" name="email" value="<?= set_value('email'); ?>">
                            <?= form_error('email', '<small class="form-text text-danger">', '</small>'); ?>
                        </div>
                        <div class="col-6 form-group">
                            <label for="perfil_usuario">Perfil:</label>
                            <select name="perfil_usuario" class="form-control">
                                <option value="1">Administrador</option>
                                <option value="2">Vendedor</option>
                            </select>
                            <?= form_error('perfil_usuario', '<small class="form-text text-danger">', '</small>'); ?>
                        </div>
                        <div class="col-6 form-group">
                            <label for="ativo">Ativo:</label>
                            <select name="ativo" class="form-control">
                                <option value="0">Não</option>
                                <option value="1">Sim</option>
                            </select>
                            <?= form_error('ativo', '<small class="form-text text-danger">', '</small>'); ?>
                        </div>
                        <div class="col-6 form-group">
                            <label for="pwd">Senha:</label>
                            <input type="password" class="form-control" placeholder="Digite uma senha" id="senha" name="senha">
                            <?= form_error('senha', '<small class="form-text text-danger">', '</small>'); ?>
                        </div>
                        <div class="col-6 form-group">
                            <label for="pwd">Confirme a senha:</label>
                            <input type="password" class="form-control" placeholder="Confirme a senha" id="confirme_senha" name="confirme_senha">
                            <?= form_error('confirme_senha', '<small class="form-text text-danger">', '</small>'); ?>
                        </div>
                        <div class="col-12 text-center">
                            <button type="submit" class="btn btn-primary">Salvar</button>
                            <a href="<?= base_url('usuarios/'); ?>" class="btn btn-secondary">Cancelar</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- /.container-fluid -->
</div>
<!-- End of Main Content -->