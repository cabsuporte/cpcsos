<?php $this->load->view('layout/sidebar'); ?>

<!-- Main Content -->
<div id="content">
    <?php $this->load->view('layout/navbar'); ?>

    <!-- Begin Page Content -->
    <div class="container-fluid">

        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?= base_url(); ?>">Home</a></li>
                <li class="breadcrumb-item"><a href="<?= base_url($this->router->fetch_class()); ?>"><?= $this->router->fetch_class(); ?></a></li>
                <li class="breadcrumb-item active" aria-current="page"><?= $titulo; ?></li>
            </ol>
        </nav>
        
        <?php if ($message = $this->session->flashdata('sucesso')): ?>
                <div class="row mt-3 mb-1">
                    <div class="col-lg-12">
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <h5><i class="fas fa-exclamation-triangle">&nbsp;</i><?= $message; ?></h5>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><i class="ik ik-x"></i></button>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            <?php if ($message = $this->session->flashdata('error')): ?>
                <div class="row mt-3 mb-1">
                    <div class="col-lg-12">
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <h5><i class="fas fa-exclamation-triangle">&nbsp;</i><?= $message; ?></h5>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><i class="ik ik-x"></i></button>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <div class="row">
                    <div class="col-6">
                        <h6 class="m-0 font-weight-bold text-primary"><?= $titulo; ?></h6>
                    </div>
                    <div class="col-6">
                    </div>
                </div>
            </div>
            <div class="card-body">
                <form method="POST" name="form_edit">
                    <div class="row">
                        <div class="col-3 form-group">
                            <label for="sistema_razao_social">Razão Social:</label>
                            <input type="text" class="form-control" placeholder="Razão Social" 
                                   id="sistema_razao_social" name="sistema_razao_social" value="<?= $sistema->sistema_razao_social; ?>">
                            <?= form_error('sistema_razao_social', '<small class="form-text text-danger">', '</small>'); ?>
                        </div>
                        <div class="col-3 form-group">
                            <label for="sistema_nome_fantasia">Nome Fantasia:</label>
                            <input type="text" class="form-control" placeholder="Nome Fantasia" 
                                   id="sistema_nome_fantasia" name="sistema_nome_fantasia" value="<?= $sistema->sistema_nome_fantasia; ?>">
                            <?= form_error('sistema_nome_fantasia', '<small class="form-text text-danger">', '</small>'); ?>
                        </div>
                        <div class="col-3 form-group">
                            <label for="sistema_cnpj">CNPJ:</label>
                            <input type="text" class="form-control cnpj" placeholder="CNPJ" 
                                   id="sistema_cnpj" name="sistema_cnpj" value="<?= $sistema->sistema_cnpj; ?>">
                            <?= form_error('sistema_cnpj', '<small class="form-text text-danger">', '</small>'); ?>
                        </div>
                        <div class="col-3 form-group">
                            <label for="sistema_ie">Inscrição Estadual:</label>
                            <input type="text" class="form-control" placeholder="Inscrição Estudual" 
                                   id="sistema_ie" name="sistema_ie" value="<?= $sistema->sistema_ie; ?>">
                            <?= form_error('sistema_ie', '<small class="form-text text-danger">', '</small>'); ?>
                        </div>
                        <div class="col-3 form-group">
                            <label for="sistema_telefone_fixo">Telefone fixo:</label>
                            <input type="text" class="form-control sp_celphones" placeholder="Inscrição Estudual" 
                                   id="sistema_telefone_fixo" name="sistema_telefone_fixo" value="<?= $sistema->sistema_telefone_fixo; ?>">
                            <?= form_error('sistema_telefone_fixo', '<small class="form-text text-danger">', '</small>'); ?>
                        </div>
                        <div class="col-3 form-group">
                            <label for="sistema_telefone_movel">Celular:</label>
                            <input type="text" class="form-control sp_celphones" placeholder="Inscrição Estudual" 
                                   id="sistema_telefone_movel" name="sistema_telefone_movel" value="<?= $sistema->sistema_telefone_movel; ?>">
                            <?= form_error('sistema_telefone_movel', '<small class="form-text text-danger">', '</small>'); ?>
                        </div>
                        <div class="col-3 form-group">
                            <label for="sistema_email">E-mail:</label>
                            <input type="text" class="form-control" placeholder="email@empresa.com.br" 
                                   id="sistema_email" name="sistema_email" value="<?= $sistema->sistema_email; ?>">
                            <?= form_error('sistema_email', '<small class="form-text text-danger">', '</small>'); ?>
                        </div>
                        <div class="col-3 form-group">
                            <label for="sistema_site_url">Site (URL):</label>
                            <input type="text" class="form-control" placeholder="www.siteempresa.com.br" 
                                   id="sistema_site_url" name="sistema_site_url" value="<?= $sistema->sistema_site_url; ?>">
                            <?= form_error('sistema_site_url', '<small class="form-text text-danger">', '</small>'); ?>
                        </div>
                        <div class="col-3 form-group">
                            <label for="sistema_cep">CEP:</label>
                            <input type="text" class="form-control cep" placeholder="CEP" 
                                   id="sistema_cep" name="sistema_cep" value="<?= $sistema->sistema_cep; ?>">
                            <?= form_error('sistema_cep', '<small class="form-text text-danger">', '</small>'); ?>
                        </div>
                        <div class="col-3 form-group">
                            <label for="sistema_endereco">Endereço:</label>
                            <input type="text" class="form-control" placeholder="Endereço" 
                                   id="sistema_endereco" name="sistema_endereco" value="<?= $sistema->sistema_endereco; ?>">
                            <?= form_error('sistema_endereco', '<small class="form-text text-danger">', '</small>'); ?>
                        </div>
                        <div class="col-3 form-group">
                            <label for="sistema_numero">Número:</label>
                            <input type="text" class="form-control" placeholder="Número" 
                                   id="sistema_numero" name="sistema_numero" value="<?= $sistema->sistema_numero; ?>">
                            <?= form_error('sistema_numero', '<small class="form-text text-danger">', '</small>'); ?>
                        </div>
                        <div class="col-3 form-group">
                            <label for="sistema_cidade">Cidade:</label>
                            <input type="text" class="form-control" placeholder="Cidade" 
                                   id="sistema_cidade" name="sistema_cidade" value="<?= $sistema->sistema_cidade; ?>">
                            <?= form_error('sistema_cidade', '<small class="form-text text-danger">', '</small>'); ?>
                        </div>
                        <div class="col-3 form-group">
                            <label for="sistema_estado">Estado:</label>
                            <input type="text" class="form-control uf" placeholder="Estado" 
                                   id="sistema_estado" name="sistema_estado" value="<?= $sistema->sistema_estado; ?>">
                            <?= form_error('sistema_estado', '<small class="form-text text-danger">', '</small>'); ?>
                        </div>
                        <div class="col-12 form-group">
                            <label for="sistema_txt_ordem_servico">Texto da Ordem de Serviço:</label>
                            <textarea type="text" class="form-control" placeholder="Ordem de Serviço" id="sistema_txt_ordem_servico" name="sistema_txt_ordem_servico"><?= $sistema->sistema_txt_ordem_servico; ?></textarea>
                            <?= form_error('sistema_txt_ordem_servico', '<small class="form-text text-danger">', '</small>'); ?>
                        </div>
                        <div class="col-12 text-center">
                            <input type="hidden" name="sistema_id" id="sistema_id" value="<?= $sistema->sistema_id; ?>" >
                            <button type="submit" class="btn btn-primary btn-lg">Salvar</button>
                            <a href="<?= base_url('sistema/'); ?>" class="btn btn-secondary btn-lg">Cancelar</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- /.container-fluid -->
</div>
<!-- End of Main Content -->