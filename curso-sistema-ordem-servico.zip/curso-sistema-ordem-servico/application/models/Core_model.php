<?php

defined('BASEPATH') OR exit('Ação não permitida');
// Este Core será usada como CRUD, pois as váriaveis $table, $data e $condition, serão equivalentes a Tabelas, Campos e Condições do banco de dados.

class Core_model extends CI_Model {

    public function OBTEM_TUDO($table = NULL, $condition = NULL) {
        if ($table && $this->db->table_exists($table)) {
            if (is_array($condition)) {
                $this->db->WHERE($condition);
            }
            return $this->db->GET($table)->result();
        } else {
            return FALSE;
        }
    }

    public function OBTEM_UM_SO($table = NULL, $condition = NULL) {
        if ($table && $this->db->table_exists($table) && is_array($condition)) {

            $this->db->WHERE($condition);
            $this->db->limit(1);

            return $this->db->GET($table)->row();
        } else {
            return FALSE;
        }
    }

    public function INSERIR($table = NULL, $data = NULL, $get_last_id = NULL) {
        if ($table && $this->db->table_exists($table) && is_array($data)) {
            
            $this->db->INSERT($table, $data);
            
            // Armazena na sessão o ultimo ID inserido na tabela
            if($get_last_id){
                $this->session->set_userdata('last_id', $this->db->insert_id()); // Deixará disponibilidzado na sessão o ultimo ID inserido.
            }

            if ($this->db->affected_rows() > 0) {
                $this->session->set_flashdata('sucesso', 'Dados salvos com sucesso!');
            }else{
                $this->session->set_flashdata('error', 'Não foi possível salvar os dados!!');
            }
        } else {
            return false;
        }
    }
    
    public function ATUALIZAR($table = NULL, $data = NULL, $condition = NULL) {
        if($table && $this->db->table_exists($table) && is_array($data) && is_array($condition)){
            if($this->db->UPDATE($table, $data, $condition)){
                $this->session->set_flashdata('sucesso', 'Atualização realizada com sucesso!');
            }else{
                $this->session->set_flashdata('sucesso', 'Atualização não realizada, verifique o código!');
            }
        }else{
           return false;
        }
    }
    
    public function DELETAR($table = NULL, $data = NULL, $condition = NULL){
        if($table && $this->db->table_exists($table) && is_array($data)){
            if($this->db->DELETE($table, $data)){
                $this->session->set_flashdata('sucesso', 'Dados excluídos!');
            }else{
                $this->session->set_flashdata('sucesso', 'Dados não excluídos, verifique o código!');
            }
        }else{
            return false;
        }
    }

}