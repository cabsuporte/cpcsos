<?php

defined('BASEPATH') OR exit('Nenhuma ação permitida');

class Login extends CI_Controller {

    public function index() {

        $data = array(
            'titulo' => 'Login CSOS'
        );
        
        $this->load->view('layout/_header', $data);
        $this->load->view('login/index');
        $this->load->view('layout/_footer');
    }

    public function auth() {

        $identity = $this->security->xss_clean($this->input->POST('email'));
        $password = $this->security->xss_clean($this->input->POST('senha'));
        $remember = FALSE; // remember the user
        if ($this->ion_auth->login($identity, $password, $remember)) {
            redirect('home');
        } else {
            $this->session->set_flashdata('error', 'Verifique suas credenciais!');
            redirect('login');
        }
    }
    
    public function Logout() {
        $this->ion_auth->logout();
        redirect($this->router->fetch_class());
    }

}
