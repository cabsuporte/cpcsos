<?php

defined('BASEPATH')OR exit('Nenhuma ação permitida!');

class Clientes extends CI_Controller {

//    public function __construct() {
//        parent::__construct();
//
//        if (!$this->ion_auth->logged_in()) {
//            $this->session->set_flashdata('info', 'Sua sessão expirou!');
//            redirect('login');
//        }
//    }


    public function index() {
        $data = array(
            'titulo' => 'Clientes cadastrados',
            'styles' => array(
                'vendor/datatables/dataTables.bootstrap4.css',
            ),
            'scripts' => array(
                'vendor/datatables/jquery.dataTables.min.js',
                'vendor/datatables/dataTables.bootstrap4.min.js',
                'vendor/datatables/app.js',
            ),
            'clientes' => $this->Core_model->OBTEM_TUDO('clientes'),
        );

//        echo '<pre>';
//        print_r($data['clientes']);
//        exit();

        $this->load->view('layout/_header', $data);
        $this->load->view('clientes/index');
        $this->load->view('layout/_footer');
    }

    public function Novo() {
        $this->form_validation->set_rules('cliente_nome', '', 'trim|required|min_length[5]|max_length[45]');
        $this->form_validation->set_rules('cliente_sobrenome', '', 'trim|required|min_length[5]|max_length[45]');
        $this->form_validation->set_rules('cliente_obs', '', 'trim|max_length[500]');
        $this->form_validation->set_rules('cliente_cep', '', 'trim|required|exact_length[9]');
        //$this->form_validation->set_rules('cliente_cpf_cnpj', '', 'trim|exact_length[18]'); // Ter atenção nesta linha e regra, pois CPF não tem a mesma quantidade de caracteres que o CNPJ.
        $this->form_validation->set_rules('cliente_email', '', 'trim|required|max_length[150]');
        $this->form_validation->set_rules('cliente_telefone', '', 'trim|required|max_length[20]');
        $this->form_validation->set_rules('cliente_celular', '', 'trim|required|max_length[20]');
        $this->form_validation->set_rules('cliente_estado', '', 'trim|required|exact_length[2]');

        if ($this->form_validation->run()) {
            $data = elements(
                    array(
                        'cliente_nome',
                        'cliente_sobrenome',
                        'cliente_tipo',
                        'cliente_data_nascimento',
                        'cliente_cpf_cnpj',
                        'cliente_rg_ie',
                        'cliente_email',
                        'cliente_telefone',
                        'cliente_celular',
                        'cliente_cep',
                        'cliente_endereco',
                        'cliente_numero_endereco',
                        'cliente_bairro',
                        'cliente_complemento',
                        'cliente_cidade',
                        'cliente_estado',
                        'cliente_nome_pai',
                        'cliente_nome_mae',
                        'cliente_ativo',
                        'cliente_obs',
                    ), $this->input->POST()
            );

            $data = html_escape($data);

            $this->Core_model->INSERIR('clientes', $data);
            redirect('clientes/');
        } else {
            // Erro de validação.
            $data = array(
                'titulo' => 'Cliente novo',
                'scripts' => array(
                    'js/mask/jquery.mask.min.js', // Esse JQ sempre vem primeiro, senão não funciona as mascaras!
                    'js/mask/app.js',
                ),
            );

            $this->load->view('layout/_header', $data);
            $this->load->view('clientes/novo');
            $this->load->view('layout/_footer');
        }
    }

    public function Editar($cliente_id = null) {
        if (!$cliente_id || !$this->Core_model->OBTEM_UM_SO('clientes', array('cliente_id' => $cliente_id))) {
            $this->session->set_flashdata('error', 'Cliente não encontrado!');
            redirect('cliente');
        } else {
            // Edição de dados
            $this->form_validation->set_rules('cliente_nome', 'NOME', 'trim|required|min_length[5]|max_length[45]');
            $this->form_validation->set_rules('cliente_obs', '', 'trim|max_length[500]');
            $this->form_validation->set_rules('cliente_cep', '', 'trim|exact_length[9]');

            $cliente_tipo = $this->input->POST('cliente_tipo');

            if ($cliente_tipo == 1) {
                $this->form_validation->set_rules('cliente_cpf', '', 'trim|callback_valida_cpf'); // Ter atenção nesta linha e regra, pois CPF não tem a mesma quantidade de caracteres que o CNPJ.    
            } else {
                $this->form_validation->set_rules('cliente_cnpj', '', 'trim|required|exact_legth[18]|callback_valida_cnpj'); // Ter atenção nesta linha e regra, pois CPF não tem a mesma quantidade de caracteres que o CNPJ.
            }

            $this->form_validation->set_rules('cliente_rg_ie', '', 'trim|required|max_length[20]|callback_check_rg_ie');
            $this->form_validation->set_rules('cliente_email', '', 'trim|required|valid_email|callback_check_email');

            if (!empty($this->input->POST('cliente_telefone'))) {
                $this->form_validation->set_rules('cliente_telefone', '', 'trim|max_length[14]|callback_check_telefone');
            }
            if (!empty($this->input->POST('cliente_celular'))) {
                $this->form_validation->set_rules('cliente_celular', '', 'trim|max_length[20]|callback_check_celular');
            }

            $this->form_validation->set_rules('cliente_estado', '', 'trim|exact_length[2]');

            if ($this->form_validation->run()) {
                $data = elements(
                        array(
                            'cliente_nome',
                            'cliente_sobrenome',
                            'cliente_tipo',
                            'cliente_data_nascimento',
                            'cliente_cpf_cnpj',
                            'cliente_rg_ie',
                            'cliente_email',
                            'cliente_telefone',
                            'cliente_celular',
                            'cliente_cep',
                            'cliente_endereco',
                            'cliente_numero_endereco',
                            'cliente_bairro',
                            'cliente_complemento',
                            'cliente_cidade',
                            'cliente_estado',
                            'cliente_nome_pai',
                            'cliente_nome_mae',
                            'cliente_ativo',
                            'cliente_obs',
                        ), $this->input->POST()
                );
                $data = html_escape($data);

                $this->Core_model->ATUALIZAR('clientes', $data, array('cliente_id' => $cliente_id));
                redirect($this->router->fetch_class());
            } else {
                // erro de validação!
                $data = array(
                    'titulo' => 'Atualizar clientes',
                    'scripts' => array(
                        'js/mask/jquery.mask.min.js', // Esse JQ sempre vem primeiro, senão não funciona as mascaras!
                        'js/mask/app.js',
                    ),
                    'cliente' => $this->Core_model->OBTEM_UM_SO('clientes', array('cliente_id' => $cliente_id)),
                );

                $this->load->view('layout/_header', $data);
                $this->load->view('clientes/editar');
                $this->load->view('layout/_footer');
            }
        }
    }

    public function Excluir() {
        
    }

    public function check_rg_ie($cliente_rg_ie) {
        $cliente_id = $this->input->POST('cliente_id');

        if ($this->Core_model->OBTEM_UM_SO('clientes', array('cliente_rg_ie' => $cliente_rg_ie, 'cliente_id !=' => $cliente_id))) {
            $this->form_validation->set_message('check_rg_ie', 'Esse documento já existe!');
            return FALSE;
        } else {
            return TRUE;
        }
    }

    public function check_email($cliente_email) {
        $cliente_id = $this->input->POST('cliente_id');

        if ($this->Core_model->OBTEM_UM_SO('clientes', array('cliente_email' => $cliente_email, 'cliente_id !=' => $cliente_id))) {
            $this->form_validation->set_message('check_email', 'Esse e-mail já existe!');
            return FALSE;
        } else {
            return TRUE;
        }
    }

    public function check_telefone($cliente_telefone) {
        $cliente_id = $this->input->POST('cliente_id');

        if ($this->Core_model->OBTEM_UM_SO('clientes', array('cliente_telefone' => $cliente_telefone, 'cliente_id !=' => $cliente_id))) {
            $this->form_validation->set_message('check_telefone', 'Esse telefone já existe!');
            return FALSE;
        } else {
            return TRUE;
        }
    }

    public function check_celular($cliente_celular) {
        $cliente_id = $this->input->POST('cliente_id');

        if ($this->Core_model->OBTEM_UM_SO('clientes', array('cliente_celular' => $cliente_celular, 'cliente_id !=' => $cliente_id))) {
            $this->form_validation->set_message('check_celular', 'Esse celular já existe!');
            return FALSE;
        } else {
            return TRUE;
        }
    }
    
    ﻿public function valida_cpf($cpf) {

        if ($this->input->post('cliente_id')) {

            $cliente_id = $this->input->post('cliente_id');

            if ($this->Core_model->OBTEM_UM_SO('clientes', array('cliente_id !=' => $cliente_id, 'cliente_cpf_cnpj' => $cpf))) {
                $this->form_validation->set_message('valida_cpf', 'Este CPF já existe');
                return FALSE;
            }
        }

        $cpf = str_pad(preg_replace('/[^0-9]/', '', $cpf), 11, '0', STR_PAD_LEFT);
        // Verifica se nenhuma das sequências abaixo foi digitada, caso seja, retorna falso
        if (strlen($cpf) != 11 || $cpf == '00000000000' || $cpf == '11111111111' || $cpf == '22222222222' || $cpf == '33333333333' || $cpf == '44444444444' || $cpf == '55555555555' || $cpf == '66666666666' || $cpf == '77777777777' || $cpf == '88888888888' || $cpf == '99999999999') {

            $this->form_validation->set_message('valida_cpf', 'Por favor digite um CPF válido');
            return FALSE;
        } else {
            // Calcula os números para verificar se o CPF é verdadeiro
            for ($t = 9; $t < 11; $t++) {
                for ($d = 0, $c = 0; $c < $t; $c++) {

                    $d += $cpf[$c] * (($t + 1) - $c); 
                }
                $d = ((10 * $d) % 11) % 10;
                if ($cpf[$c] != $d) {
                    $this->form_validation->set_message('valida_cpf', 'Por favor digite um CPF válido');
                    return FALSE;
                }
            }
            return TRUE;
        }
    }
}