<?php

defined('BASEPATH') OR exit('Nenhuma ação prmitida!');

class Sistema extends CI_Controller {

//    public function __construct(){
//        parent::__construct();
//
//        if (!$this->ion_auth->logged_in()) {
//            $this->session->set_flashdata('info', 'Sua sessão expirou!');
//            redirect('login');
//        }
//    }

    public function index() {
        $data = array(
            'titulo' => 'Editar informações do sistema',
            'sistema' => $this->Core_model->OBTEM_UM_SO('sistema', array('sistema_id' => 1)),
            'scripts' => array(
                'js/mask/jquery.mask.min.js', // Esse JQ sempre vem primeiro, senão não funciona as mascaras!
                'js/mask/app.js',
            )
        );

        $this->form_validation->set_rules('sistema_razao_social', 'RAZÃO SOCIAL', 'trim|required|min_length[10]|max_length[145]');
        $this->form_validation->set_rules('sistema_nome_fantasia', 'NOME FANTASIA', 'trim|required|min_length[5]|max_length[145]');
        $this->form_validation->set_rules('sistema_cnpj', 'CNPJ', 'trim|required|exact_length[18]'); // 18 char
        $this->form_validation->set_rules('sistema_ie', 'INSCRIÇÃO ESTADUAL', 'trim|required|max_length[25]');
        $this->form_validation->set_rules('sistema_telefone_fixo', 'TELEFONE', 'trim|required|max_length[25]');
        $this->form_validation->set_rules('sistema_telefone_movel', 'CELULAR', 'trim|required|max_length[25]');
        $this->form_validation->set_rules('sistema_email', 'E-MAIL', 'trim|valid_email|required|max_length[100]');
        $this->form_validation->set_rules('sistema_site_url', 'URL DO SITE', 'trim|valid_url|required|max_length[100]');
        $this->form_validation->set_rules('sistema_cep', 'CEP', 'trim|required|max_length[9]');
        $this->form_validation->set_rules('sistema_endereco', 'ENDEREÇO', 'trim|required|max_length[145]');
        $this->form_validation->set_rules('sistema_numero', 'NUMERO', 'trim|required|max_length[25]');
        $this->form_validation->set_rules('sistema_cidade', 'CIDADE', 'trim|required|max_length[45]');
        $this->form_validation->set_rules('sistema_estado', 'UF', 'trim|required|max_length[2]');
        $this->form_validation->set_rules('sistema_txt_ordem_servico', 'TEXTO DA O.S', 'trim|max_length[500]');

        if ($this->form_validation->run()) {
            $data = elements(
                    array(
                        'sistema_razao_social',
                        'sistema_nome_fantasia',
                        'sistema_cnpj',
                        'sistema_ie',
                        'sistema_telefone_fixo',
                        'sistema_telefone_movel',
                        'sistema_email',
                        'sistema_site_url',
                        'sistema_cep',
                        'sistema_endereco',
                        'sistema_numero',
                        'sistema_cidade',
                        'sistema_estado',
                        'sistema_txt_ordem_servico',
                    ), $this->input->POST()
            );
            
            $data = html_escape($data);
            
            $this->Core_model->ATUALIZAR('sistema', $data, array('sistema_id' => 1));
            redirect('sistema');

//            echo '<pre>';
//            print_r($this->input->POST());
//            exit();
        } else {
            echo 'Erro de validação!';
        }

        $this->load->view('layout/_header', $data);
        $this->load->view('sistema/index');
        $this->load->view('layout/_footer');
    }

}
