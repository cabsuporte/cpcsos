<?php

defined('BASEPATH') OR Exit('Ação não permitida!');

class Usuarios extends CI_Controller {

//    public function __construct() {
//        parent::__construct();
//
//        if (!$this->ion_auth->logged_in()) {
//            $this->session->set_flashdata('info', 'Sua sessão expirou!');
//            redirect('login');
//        }
//    }

    public function index() {
        $data = array(
            'titulo' => 'Lista de usuários',
            'styles' => array(
                'vendor/datatables/dataTables.bootstrap4.min.css',
            ),
            'scripts' => array(
                'vendor/datatables/jquery.dataTables.min.js',
                'vendor/datatables/dataTables.bootstrap4.min.js',
                'vendor/datatables/app.js',
            ),
            'usuarios' => $this->ion_auth->users()->result(),
        );
        $this->load->view('layout/_header', $data);
        $this->load->view('usuarios/index');
        $this->load->view('layout/_footer');
    }

    public function Novo() {

        $this->form_validation->set_rules('first_name', 'o campo Nome ', 'trim|required');
        $this->form_validation->set_rules('last_name', 'o campo Sobremone ', 'trim|required');
        $this->form_validation->set_rules('username', 'o campo Usuário ', 'trim|required|is_unique[users.username]');
        $this->form_validation->set_rules('email', 'o campo E-mail ', 'trim|required|valid_email|is_unique[users.email]');
        $this->form_validation->set_rules('password', 'SENHA', 'trim|required|min_length[5]|max_length[255]');
        $this->form_validation->set_rules('password_confirm', 'CONFIRME A SENHA', 'trim|matches[senha]'); // Aqui no validação MATCHES[tem que ser o nome do campo senha no formulário]

        if ($this->form_validation->run()) {
            $username = $this->security->xss_clean($this->input->POST('username'));
            $password = $this->security->xss_clean($this->input->POST('senha'));
            $email = $this->security->xss_clean($this->input->POST('email'));
            
            $additional_data = array(
                'username' => $this->input->POST('username'),
                'first_name' => $this->input->POST('first_name'),
                'last_name' => $this->input->POST('last_name'),
                'active' => $this->input->POST('active'),
            );
            $group = array($this->input->POST('perfil_usuario')); // Sets user to admin.
            
            $additional_data = $this->security->xss_clean($additional_data);
            
            $group = $this->security->xss_clean($group);
            
            if($this->ion_auth->register($username, $password, $email, $additional_data, $group)){
                $this->session->set_flashdata('sucesso', 'Dados salvos com sucesso!');
                redirect('usuarios');
            }else{
                $this->session->set_flashdata('error', 'Erro al salvar os dados!');
                redirect('usuarios/novo');
            }
            redirect('usuarios');

//            echo '<pre>';
//            print_r($this->input->post());
//            exit('-- Funcionando! --');
        } else {
            $data = array(
                'titulo' => 'Novo usuário',
            );

            $this->load->view('layout/_header', $data);
            $this->load->view('usuarios/novo');
            $this->load->view('layout/_footer');
        }
    }

    public function Editar($usuario_id = NULL) {
        if (!$usuario_id || !$this->ion_auth->user($usuario_id)->row()) {
            $this->session->set_flashdata('error', 'Usuário não encontrado!');
            redirect('usuarios');
        } else {
            $this->form_validation->set_rules('first_name', 'o campo Nome ', 'trim|required');
            $this->form_validation->set_rules('last_name', 'o campo Sobremone ', 'trim|required');
            $this->form_validation->set_rules('username', 'o campo Usuário ', 'trim|required|callback_username_check');
            $this->form_validation->set_rules('email', 'o campo E-mail ', 'trim|required|valid_email|callback_email_check');
            $this->form_validation->set_rules('password', 'SENHA', 'trim|min_length[5]|max_length[255]');
            $this->form_validation->set_rules('password_confirm', 'CONFIRME A SENHA', 'trim|matches[password]'); // Aqui no validação MATCHES[tem que ser o nome do campo senha no formulário]

            if ($this->form_validation->run()) {
                $data = elements( // Em caso de utilização ARRAY no helper, a variavel criada no conjunto elements, tem que estar com o mesmo nome no atributo NAME do campo e tamném na tabela de banco de dados, para dar certo!
                        array( // Nos itens abaixo, são consideraveis variaveis associativas, no atributo NAME da propriedade CAMPO, é necessário esta com o mesmo nome.
                            'first_name',
                            'last_name',
                            'username',
                            'email',
                            'password',
                            'active',
                        ), $this->input->POST()
                );

                $data = $this->security->xss_clean($data);

                // Verifica se foi passado a senha
                $password = $this->input->POST('password');
                if (!$password) {
                    unset($data['password']);
                }

                $data = html_escape($data);

                if ($this->ion_auth->UPDATE($usuario_id, $data)) {
                    $perfil_usuario_db = $this->ion_auth->get_users_groups($usuario_id)->row(); //Obtem uma linha de acordo com o ID para atualização
                    $perfil_usuario_post = $this->input->POST('perfil_usuario'); //Obtem o valor de seleção do campo do formulário.

                    /* se for diferente atualiza o grupo (perfil) */
                    if ($perfil_usuario_post != $perfil_usuario_db->id) {
                        $this->ion_auth->remove_from_group($perfil_usuario_db->id, $usuario_id);
                        $this->ion_auth->add_to_group($perfil_usuario_post, $usuario_id);
                    }

                    $this->session->set_flashdata('sucesso', 'Dados salvos com sucesso!');
                    redirect('usuarios');
                } else {
                    $this->session->set_flashdata('error', 'Erro ao salvar dados!');
                    redirect('usuarios/editar/');
                }
                redirect('usuarios');
            } else {
                $data = array(
                    'titulo' => 'Editar usuários',
                    'usuario' => $this->ion_auth->user($usuario_id)->row(),
                    'perfil_usuario' => $this->ion_auth->get_users_groups($usuario_id)->row(),
                );

                $this->load->view('layout/_header', $data);
                $this->load->view('usuarios/editar');
                $this->load->view('layout/_footer');
            }
        }

        //        [first_name] => Admin
//                [last_name] => istrator
//                [username] => administrator
//                [email] => admin@admin.com
//                [perfil_usuario] => 1
//                [ativo] => 1
//                [senha] =>
//                [confirme_senha] =>
//                [user_id] => 1
//                echo '<pre>';
//                print_r($this->input->post());
//                exit();
    }

    public function email_check($email) {
        $usuario_id = $this->input->POST('usuario_id');

        if ($this->Core_model->OBTEM_UM_SO('users', array('email' => $email, 'id !=' => $usuario_id))) {
            $this->form_validation->set_message('email_check', 'Esse e-mail já existe!');
            return FALSE;
        } else {
            return TRUE;
        }
    }

    public function username_check($username) {
        $usuario_id = $this->input->POST('usuario_id');

        if ($this->Core_model->OBTEM_UM_SO('users', array('username' => $username, 'id !=' => $usuario_id))) {
            $this->form_validation->set_message('username_check', 'Esse e-mail já existe!');
            return FALSE;
        } else {
            return TRUE;
        }
    }
    
    public function Del($usuario_id = NULL){
        if(!$usuario_id || !$this->ion_auth->user($usuario_id)->row()){
            $this->session->set_flashdata('error', 'Usuario não encontrado!');
            redirect('usuarios');
        }
        
        if($this->ion_auth->is_admin($usuario_id)){
            $this->session->set_flashdata('error', 'O administrador não pode ser excluido!');
            redirect('usuarios');
        }
        
        if($this->ion_auth->delete_user($usuario_id)){
            $this->session->set_flashdata('sucesso','Usuário excluido!');
            redirect('usuarios');
        }else{
            $this->session->set_flashdata('error', 'Erro ao excluir o usuário!');
            redirect('usuarios');
        }
    }

}
